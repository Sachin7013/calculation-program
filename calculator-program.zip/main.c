
#include <stdio.h>

int main()
{
   double a,b;
   char operator;
   printf("enter the value of a:");
   scanf("%lf", &a);
   printf("enter the operator (+,-,*,/):");
   scanf(" %c", &operator);
   printf ("enthe the value of b:");
   scanf("%lf", &b);
   
       switch(operator){
       case '+':
        printf("result:%.2lf",a+b);
        break;
       case '-':
        printf("result:%.2lf",a-b);
        break;
       case '*':
        printf("result:%.2lf",a*b);
        break;
       case '/':
       printf("Result: %.2lf\n", a / b);
       break;
       default: 
        printf("enter the correct operator");
           
       }
       
       return 0;
   
  
}
